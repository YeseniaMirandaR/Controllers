const express = require('express');
const QuotesRouter = express.Router();
const {QuotesController} = require('./../controllers/quotesController')

QuotesRouter
    .get('/', QuotesController.showMain);

QuotesRouter
    .get('/quotes', QuotesController.renderQuote);

QuotesRouter
    .post('/quotes', QuotesController.createQuote);

module.exports = {QuotesRouter};